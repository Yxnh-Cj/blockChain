function y =fun1( x )
y = 4*cos(x)-exp(x);

end

