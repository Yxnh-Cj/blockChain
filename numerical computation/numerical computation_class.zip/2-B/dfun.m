function y =dfun(x)
y = 3*x^2-3;


end

