function y = fun(x)
y = x^3-3*x-1;
end

