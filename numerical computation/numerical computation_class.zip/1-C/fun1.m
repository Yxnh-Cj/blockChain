function y = fun1(x)
y = (x+1)^(1/3);
end

