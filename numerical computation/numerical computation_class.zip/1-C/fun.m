function y = fun(x)
y=1-x-sin(x);
end

