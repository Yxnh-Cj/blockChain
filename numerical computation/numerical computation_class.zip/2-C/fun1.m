function y = fun1( x )
y = x-exp(-x);


end

