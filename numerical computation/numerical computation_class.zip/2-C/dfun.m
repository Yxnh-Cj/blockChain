function y =dfun(x)
y = 3*x^2-2*x;

end

