function y = newton_iteration_fun_dfun(x)
y = 3*x^2+4*x+10;
end
