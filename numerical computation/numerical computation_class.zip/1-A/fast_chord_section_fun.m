function y = fast_chord_section_fun(x)
y = x^3+x*x^2+10*x-20;
end

