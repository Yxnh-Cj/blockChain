function y = simple_iteration_fun(x)
y = 20/(x^2+2*x+10);
end

