function y = dichotomy_fun(x)
y = x^3-x^2-1;
end

