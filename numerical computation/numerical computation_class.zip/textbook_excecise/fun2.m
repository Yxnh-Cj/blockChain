function y = fun2(x)
y = (x-1)^(-1/2)
end