function y = fun(x)
y = 1+x^(-2);
end

