function y = fun1(x)
y = (1+x^2)^(1/3);
end